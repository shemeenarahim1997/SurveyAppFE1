import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
@Injectable({
  providedIn: 'root'
})
export class TableidService {

  constructor(private http: HttpClient) { }
  resourceId="5eae7981c743912094c79724";
  //  getPostId(url,resourceId)
  // {
  //  console.log(this.resourceId);
  //   // return this.http.get(url+this.resourceId);
  //   return this.http.get(url+"5eae7981c743912094c79724");
  // }
}
