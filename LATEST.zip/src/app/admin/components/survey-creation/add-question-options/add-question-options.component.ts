import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-question-options',
  templateUrl: './add-question-options.component.html',
  styleUrls: ['./add-question-options.component.css']
})
export class AddQuestionOptionsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
