import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-group',
  templateUrl: './view-group.component.html',
  styleUrls: ['./view-group.component.css']
})
export class ViewGroupComponent implements OnInit {
  groups:any;
  url:string;
  columns:any;
  _title="GROUPS"
  constructor() { }

  ngOnInit() { this.columns = [
    { field: 'group_name', header: 'GROUP' },
    { field: 'perms', header: 'PERMISSIONS' },
    { field: '', header: ''}
 ];
 console.log(this.groups);
  }

}
