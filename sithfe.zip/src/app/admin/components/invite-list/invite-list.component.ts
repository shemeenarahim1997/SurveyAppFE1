import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-invite-list',
  templateUrl: './invite-list.component.html',
  styleUrls: ['./invite-list.component.css']
})
export class InviteListComponent implements OnInit {
  users:any;
  url:string;
  columns:any;
  _title="INVITE LIST";
  resourceId="5eae7981c743912094c79724";
  constructor() { }

  ngOnInit(): void {
    // console.log(this.survey_id);
    this.columns = [
      { field: 'survey_name', header: 'SURVEY_NAME' },
      { field: 'user_name', header: 'SURVEY_RECIPIENTS' },
   ];
  }

}
